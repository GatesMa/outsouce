import main.vrp

vrP = vrp()